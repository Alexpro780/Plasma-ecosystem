# Plasma Intro

A simple introduction project for the Plasma ecosystem.  
This includes a basic overview file and a placeholder script for potential smart contract or node setup references.

## What's Inside

- `README.md`: Project overview
- `plasma_info.md`: Basic info about Plasma and its mission
- `starter.py`: Placeholder Python file for further development

Ideal for contributors who want to start experimenting or sharing ideas with the Plasma community.
